x-attribute
==========================================================

We got hold of an disk image which contains secret documents from North Korea.
Analyse the file provided to access their "secure" domain.

[link to filesys.img] 